interface Winner {
    int getYear();
    int getWinnerAge();
    String getWinnerName();
    String getFilmTitle();
}
